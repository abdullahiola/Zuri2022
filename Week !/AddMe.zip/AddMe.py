a = int(input("Enter your first number : "))
b= int(input("Enter your second number : "))

sum = a + b

print(f"The sum is {sum}")
